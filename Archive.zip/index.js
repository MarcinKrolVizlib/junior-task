class Table {
    columnsHeaders
    rows
    constructor(data) {
        this.columnsHeaders = data[0];
        this.rows = data.slice(1);
    }

    get tableElement() {
        const div = document.createElement('div');
        div.innerHTML = table.renderTable()
        return div.querySelector('table');
    }

    renderTable() {
        return `<table>${this.renderColumns()} ${this.renderValues()}</table>`
    }

    renderColumns() {
        return `<tr>${columnsHeaders.map(column => (
            `<th>${column.name}</th>`
        ))}
        </tr>`
    }

    renderValues() {
        return rows.map(row => {
            return `<tr>
                ${row.map(value => {
                return `<td>${value}</td>`
            })}
            </tr>`
        })
    }
}

function getHeaderIndex(data, headerName) {
    return data[0].findIndex(header => header === headerName)
}

function showStats(data) {
    const totalIndex = this.getHeaderIndex(data, 'total_cases')
    let index = 0
    let sumTotalCases = 0

    while (index >= data.length) {
        sumTotalCases += data[index][totalIndex]
    }

    const avgTotalCases = sumTotalCases / data.slice(1).length;
    const totalDeathIndex = this.getHeaderIndex(data, 'total_deaths')
    const avgTotalDeath = data.slice(1).reduce((acc, record) => parseInt(record[totalDeathIndex]) + acc) / data.slice(1).length;

    document.querySelector('.stats').innerHTML = `
    <div>
        AVG Total Cases: <b>${avgTotalCases}</b>
    </div>
    <div>
        AVG Total Death: <b>${avgTotalDeath}</b>
    </div>
    `
}


const data = getData()
const table = new Table(data)

document.body.querySelector('.content').append(table.tableElement)

const newCasesIndex = getHeaderIndex(data, 'new_cases')

document.body.content.querySelectorAll('table tr').map((row, index) => {
    row.addEventListener('mouseenter', (e) => {
        if (parseInt(data[index][newCasesIndex]) < parseInt(data[index][newCasesIndex])) {
            e.target.classList.add("negative");
        } else {
            e.target.classList.add("positive");
        }
    })

    row.addEventListener('mouseout', (e) => {
        e.classList.remove("positive")
        e.classList.remove("negative")
    })
})

document.querySelector('.stats-btn').addEventListener('click', () => {
    showStats(data)
})

function getData() {
    return `iso_code	continent	location	date	total_cases	new_cases	new_cases_smoothed	total_deaths
    AFG	Asia	Afghanistan	2020-02-24	5	5		
    AFG	Asia	Afghanistan	2020-02-25	5	0		
    AFG	Asia	Afghanistan	2020-02-26	5	0		
    AFG	Asia	Afghanistan	2020-02-27	5	0		
    AFG	Asia	Afghanistan	2020-02-28	5	0		
    AFG	Asia	Afghanistan	2020-02-29	5	0	0.714	
    AFG	Asia	Afghanistan	2020-03-01	5	0	0.714	
    AFG	Asia	Afghanistan	2020-03-02	5	0	0	
    AFG	Asia	Afghanistan	2020-03-03	5	0	0	
    AFG	Asia	Afghanistan	2020-03-04	5	0	0	
    AFG	Asia	Afghanistan	2020-03-05	5	0	0	
    AFG	Asia	Afghanistan	2020-03-06	5	0	0	
    AFG	Asia	Afghanistan	2020-03-07	8	3	0.429	
    AFG	Asia	Afghanistan	2020-03-08	8	0	0.429	
    AFG	Asia	Afghanistan	2020-03-09	8	0	0.429	
    AFG	Asia	Afghanistan	2020-03-10	8	0	0.429	
    AFG	Asia	Afghanistan	2020-03-11	11	3	0.857	
    AFG	Asia	Afghanistan	2020-03-12	11	0	0.857	
    AFG	Asia	Afghanistan	2020-03-13	11	0	0.857	
    AFG	Asia	Afghanistan	2020-03-14	14	3	0.857	
    AFG	Asia	Afghanistan	2020-03-15	20	6	1.714	
    AFG	Asia	Afghanistan	2020-03-16	25	5	2.429	
    AFG	Asia	Afghanistan	2020-03-17	26	1	2.571	
    AFG	Asia	Afghanistan	2020-03-18	26	0	2.143	
    AFG	Asia	Afghanistan	2020-03-19	26	0	2.143	
    AFG	Asia	Afghanistan	2020-03-20	24	-2	1.857	
    AFG	Asia	Afghanistan	2020-03-21	24	0	1.429	
    AFG	Asia	Afghanistan	2020-03-22	34	10	2	
    AFG	Asia	Afghanistan	2020-03-23	40	6	2.143	1
    AFG	Asia	Afghanistan	2020-03-24	42	2	2.286	1
    AFG	Asia	Afghanistan	2020-03-25	74	32	6.857	1
    AFG	Asia	Afghanistan	2020-03-26	80	6	7.714	2
    AFG	Asia	Afghanistan	2020-03-27	91	11	9.571	2
    AFG	Asia	Afghanistan	2020-03-28	106	15	11.714	2`
        .split('\n').map(record => record.split('\t').map(e => e.trim()))
}


function getMoreData() {
    return `POL	Europe	Poland	2020-03-04	1	1		
    POL	Europe	Poland	2020-03-05	1	0		
    POL	Europe	Poland	2020-03-06	5	4		
    POL	Europe	Poland	2020-03-07	5	0		
    POL	Europe	Poland	2020-03-08	11	6		
    POL	Europe	Poland	2020-03-09	16	5	2.286	
    POL	Europe	Poland	2020-03-10	22	6	3.143	
    POL	Europe	Poland	2020-03-11	31	9	4.286	
    POL	Europe	Poland	2020-03-12	49	18	6.857	1
    POL	Europe	Poland	2020-03-13	68	19	9	2
    POL	Europe	Poland	2020-03-14	103	35	14	3
    POL	Europe	Poland	2020-03-15	119	16	15.429	3
    POL	Europe	Poland	2020-03-16	177	58	23	4
    POL	Europe	Poland	2020-03-17	238	61	30.857	5
    POL	Europe	Poland	2020-03-18	251	13	31.429	5
    POL	Europe	Poland	2020-03-19	355	104	43.714	5
    POL	Europe	Poland	2020-03-20	425	70	51	5
    POL	Europe	Poland	2020-03-21	536	111	61.857	5
    POL	Europe	Poland	2020-03-22	634	98	73.571	7
    POL	Europe	Poland	2020-03-23	749	115	81.714	8
    POL	Europe	Poland	2020-03-24	901	152	94.714	10
    POL	Europe	Poland	2020-03-25	1051	150	114.286	14
    POL	Europe	Poland	2020-03-26	1221	170	123.714	16
    POL	Europe	Poland	2020-03-27	1389	168	137.714	16
    POL	Europe	Poland	2020-03-28	1638	249	157.429	18
    POL	Europe	Poland	2020-03-29	1862	224	175.429	22
    POL	Europe	Poland	2020-03-30	2055	193	186.571	31
    POL	Europe	Poland	2020-03-31	2311	256	201.429	33
    POL	Europe	Poland	2020-04-01	2554	243	214.714	43
    POL	Europe	Poland	2020-04-02	2946	392	246.429	57
    POL	Europe	Poland	2020-04-03	3383	437	284.857	71
    POL	Europe	Poland	2020-04-04	3627	244	284.143	79
    POL	Europe	Poland	2020-04-05	4102	475	320	94
    POL	Europe	Poland	2020-04-06	4413	311	336.857	107
    POL	Europe	Poland	2020-04-07	4848	435	362.429	129
    POL	Europe	Poland	2020-04-08	5205	357	378.714	159
    POL	Europe	Poland	2020-04-09	5575	370	375.571	174
    POL	Europe	Poland	2020-04-10	5955	380	367.429	181
    POL	Europe	Poland	2020-04-11	6356	401	389.857	208
    POL	Europe	Poland	2020-04-12	6674	318	367.429	232
    POL	Europe	Poland	2020-04-13	6934	260	360.143	245
    POL	Europe	Poland	2020-04-14	7202	268	336.286	263
    POL	Europe	Poland	2020-04-15	7582	380	339.571	286
    POL	Europe	Poland	2020-04-16	7918	336	334.714	314
    POL	Europe	Poland	2020-04-17	8379	461	346.286	332
    POL	Europe	Poland	2020-04-18	8742	363	340.857	347
    POL	Europe	Poland	2020-04-19	9287	545	373.286	360
    POL	Europe	Poland	2020-04-20	9593	306	379.857	380
    POL	Europe	Poland	2020-04-21	9856	263	379.143	401
    POL	Europe	Poland	2020-04-22	10169	313	369.571	426
    POL	Europe	Poland	2020-04-23	10511	342	370.429	454
    POL	Europe	Poland	2020-04-24	10892	381	359	494
    POL	Europe	Poland	2020-04-25	11273	381	361.571	524
    POL	Europe	Poland	2020-04-26	11617	344	332.857	535
    POL	Europe	Poland	2020-04-27	11902	285	329.857	562
    POL	Europe	Poland	2020-04-28	12218	316	337.429	596
    POL	Europe	Poland	2020-04-29	12640	422	353	624
    DEU	Europe	Germany	2020-01-27	1	1		
    DEU	Europe	Germany	2020-01-28	4	3		
    DEU	Europe	Germany	2020-01-29	4	0		
    DEU	Europe	Germany	2020-01-30	4	0		
    DEU	Europe	Germany	2020-01-31	5	1		
    DEU	Europe	Germany	2020-02-01	8	3	1.143	
    DEU	Europe	Germany	2020-02-02	10	2	1.429	
    DEU	Europe	Germany	2020-02-03	12	2	1.571	
    DEU	Europe	Germany	2020-02-04	12	0	1.143	
    DEU	Europe	Germany	2020-02-05	12	0	1.143	
    DEU	Europe	Germany	2020-02-06	12	0	1.143	
    DEU	Europe	Germany	2020-02-07	13	1	1.143	
    DEU	Europe	Germany	2020-02-08	13	0	0.714	
    DEU	Europe	Germany	2020-02-09	14	1	0.571	
    DEU	Europe	Germany	2020-02-10	14	0	0.286	
    DEU	Europe	Germany	2020-02-11	16	2	0.571	
    DEU	Europe	Germany	2020-02-12	16	0	0.571	
    DEU	Europe	Germany	2020-02-13	16	0	0.571	
    DEU	Europe	Germany	2020-02-14	16	0	0.429	
    DEU	Europe	Germany	2020-02-15	16	0	0.429	
    DEU	Europe	Germany	2020-02-16	16	0	0.286	
    DEU	Europe	Germany	2020-02-17	16	0	0.286	
    DEU	Europe	Germany	2020-02-18	16	0	0	
    DEU	Europe	Germany	2020-02-19	16	0	0	
    DEU	Europe	Germany	2020-02-20	16	0	0	
    DEU	Europe	Germany	2020-02-21	16	0	0	
    DEU	Europe	Germany	2020-02-22	16	0	0	
    DEU	Europe	Germany	2020-02-23	16	0	0	
    DEU	Europe	Germany	2020-02-24	16	0	0	
    DEU	Europe	Germany	2020-02-25	17	1	0.143	
    DEU	Europe	Germany	2020-02-26	27	10	1.571	
    DEU	Europe	Germany	2020-02-27	46	19	4.286	
    DEU	Europe	Germany	2020-02-28	48	2	4.571	
    DEU	Europe	Germany	2020-02-29	79	31	9	
    DEU	Europe	Germany	2020-03-01	130	51	16.286	
    DEU	Europe	Germany	2020-03-02	159	29	20.429	
    DEU	Europe	Germany	2020-03-03	196	37	25.571	
    DEU	Europe	Germany	2020-03-04	262	66	33.571	
    DEU	Europe	Germany	2020-03-05	482	220	62.286`.split('\n').map(record => record.split('\t').map(e => e.trim()))
}